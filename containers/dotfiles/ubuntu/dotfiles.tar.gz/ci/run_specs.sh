#!/bin/bash

set -ex

bash --login -c '~/.dotfiles/bin/shpec'
