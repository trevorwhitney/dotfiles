#!/bin/bash

current_dir=$(cd $(dirname $0) && pwd)
dotfiles_dir=$(cd $current_dir/../../.. && pwd)

pushd $dotfiles_dir
  tar -czf dotfiles.tar.gz .
  mv dotfiles.tar.gz containers/dotfiles/base
popd
docker build -t dotfiles:ubuntu .
