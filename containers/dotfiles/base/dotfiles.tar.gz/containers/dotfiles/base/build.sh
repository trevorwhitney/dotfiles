#!/bin/bash

docker build -t dotfiles:base .
