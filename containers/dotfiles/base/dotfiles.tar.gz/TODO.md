1. Setup Docker for CI
